# HashCode2019
Repositorio para HashCode 2019

Para clonar el repositorio
1. Clonar repositorio:  git clone *url*           // Ponerse en la carpeta que quieras
Pasos para modificar y actualizar ramas
2. Crear rama:          git branch *nombre*       // Nombre de cada uno en minuscula: pere, alex, mario
3. Ponerse en la rama:  git checkout *nombre*
4. Comprobar:           git branch
5. *Hacer todos los cambios oportunos*
6. Añadir cambios:      git add .                 // Ponerse en la carpeta raiz. El "." es para coger toda la carpeta
7. Guardar cambios:     git commit *mensaje*      // Poner un mensaje culquiera y guardar
8. Actualizar tu rama:  git push origin *nombre*
